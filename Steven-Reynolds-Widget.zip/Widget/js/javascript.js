$(document).ready(function(){
    $('#widget-left').mouseover(function(){
        $('#widget-content').css('color', '#4b4b4b');
        $('#widget-right').css('color', '#0f0f0f');      
     });

    $('#widget-left').mouseout(function(){
        $('#widget-content').css('color', '#ffffff');
        $('#widget-right').css('color', '#4b4b4b');
     });
});

$('#widget-options').change(function()
  {
    if($(this).val()==1)
    {
      $('#widget-right').show();
      $('#widget-numbers-right').hide();
    }
    
    else
    {
      $('#widget-numbers-right').show();
      $('#widget-right').hide();
    }
});
